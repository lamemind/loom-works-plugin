# $1=envelope $2=fixture $3=transcript
env_f="$1"; fix="$2"
target="docs/reference/cc/prompt-caching.md"

# FORMA 1 — il diff non tocca file fuori dal target (PRIMA dei guardiani, che
# rigenerano l'INDEX e sporcherebbero la misura)
touched="$( (git -C "$fix" diff --name-only; git -C "$fix" ls-files --others --exclude-standard) | grep -v '^\.envelope\.json$' | sort -u )"
if [[ "$touched" == "$target" ]]; then
    b_ok "writer: FORMA — il diff tocca solo il target"
else
    b_ko "writer: FORMA — il diff tocca solo il target" "toccati: $(tr '\n' ' ' <<< "$touched")"
fi
if [[ -f "$fix/$target" ]]; then b_ok "writer: FORMA — target creato"; else b_ko "writer: FORMA — target creato"; fi

# il target è un file di reference/: TLDR in riga 3
l3="$(sed -n '3p' "$fix/$target" 2>/dev/null)"
if [[ "$l3" =~ ^\>\ \*\*TLDR\*\*:\ .+$ ]]; then
    b_ok "writer: MERITO — TLDR in riga 3 del file nuovo"
else
    b_ko "writer: MERITO — TLDR in riga 3 del file nuovo" "riga 3: $l3"
fi

# guardiani deterministici, DOPO la misura del diff
if PROJECT_ROOT="$fix" "$fix/.plugin-scripts/docs/build-index.sh" --docs-root docs >/dev/null 2>&1; then
    b_ok "writer: FORMA — build-index verde dopo la patch"
else
    rc=$?
    if [[ $rc -eq 2 ]]; then b_ok "writer: FORMA — build-index scritto (TLDR oltre cap segnalato)"; else b_ko "writer: FORMA — build-index verde dopo la patch" "exit $rc"; fi
fi
if PROJECT_ROOT="$fix" "$fix/.plugin-scripts/docs/check-doc-links.sh" --docs-root docs >/dev/null 2>&1; then
    b_ok "writer: FORMA — check-doc-links a zero"
else
    b_ko "writer: FORMA — check-doc-links a zero"
fi

# envelope: esiti per n1 e n2, scritta ⇒ come non vuoto
if jq -e '.esiti | type == "array" and length == 2' "$env_f" >/dev/null 2>&1; then
    b_ok "writer: FORMA — due esiti"
else
    b_ko "writer: FORMA — due esiti" "$(cat "$env_f")"
fi
if jq -e '[.esiti[]] | all(.esito | IN("scritta","drop"))' "$env_f" >/dev/null 2>&1; then
    b_ok "writer: FORMA — esiti nel vocabolario"
else
    b_ko "writer: FORMA — esiti nel vocabolario"
fi
if jq -e '[.esiti[] | select(.esito == "scritta")] | all(.come != null and .come != "")' "$env_f" >/dev/null 2>&1; then
    b_ok "writer: FORMA — come su ogni scritta"
else
    b_ko "writer: FORMA — come su ogni scritta"
fi
# MERITO: le due nozioni entrano davvero (nessun drop atteso su un file nuovo)
if jq -e '[.esiti[] | select(.esito == "scritta")] | length == 2' "$env_f" >/dev/null 2>&1; then
    b_ok "writer: MERITO — entrambe le nozioni scritte"
else
    b_ko "writer: MERITO — entrambe le nozioni scritte" "$(jq -c '.esiti' "$env_f")"
fi
