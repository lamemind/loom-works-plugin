Modo scrittura.

target: docs/reference/cc/prompt-caching.md
assumed_knowledge: docs/reference/assumed-knowledge.md

nozioni:

- id: n1
  settore: claude code
  grado: K1
  evidenza: file nuovo — nessuna pagina di reference/cc/ possiede il meccanismo della cache prompt; il perimetro «costo/cache di un subagent» non ha oggi un indirizzo
  testo: La cache dei prompt Anthropic è un prefix-match sui byte esatti con ordine di resa tools → system → messages: per un subagent il body dell'agent (contratti iniettati inline compresi) è il prompt di system, costante e quindi cachabile fra spawn dello stesso tipo, mentre il prompt d'invocazione è il primo messaggio user e sta dopo il breakpoint — varia liberamente senza invalidare la cache, quindi il path o il payload per-invocazione viaggiano lì.

- id: n2
  settore: claude code
  grado: K1
  evidenza: agent-sdk.md documenta il fork (forkSession) ma non cosa eredita rispetto alla cache; la nozione completa quel confine
  testo: Un subagent apre una conversazione propria, con system prompt e tool set propri, quindi non legge la cache del parent e ne scalda una sua. Un fork è il caso opposto: eredita system prompt, tool e storia del parent alla lettera, quindi la sua prima richiesta legge la cache del parent.
