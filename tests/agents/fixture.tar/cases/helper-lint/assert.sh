# $1=envelope $2=fixture $3=transcript
env_f="$1"
if jq -e '.esito.violazioni | type == "array"' "$env_f" >/dev/null 2>&1; then
    b_ok "helper-lint: FORMA — esito.violazioni è un array"
else
    b_ko "helper-lint: FORMA — esito.violazioni è un array" "$(cat "$env_f")"
fi
if jq -e '.confidence | IN("alta","media","bassa")' "$env_f" >/dev/null 2>&1; then
    b_ok "helper-lint: FORMA — confidence nel vocabolario"
else
    b_ko "helper-lint: FORMA — confidence nel vocabolario"
fi
coords="$(jq -r '[.esito.violazioni[].coordinata] | join(" ")' "$env_f" 2>/dev/null)"
case "$coords" in
    *T06*|*T15*|*T16*) b_ok "helper-lint: MERITO — coordinate nude trovate" ;;
    *) b_ko "helper-lint: MERITO — coordinate nude trovate" "coordinate: '$coords'" ;;
esac
if grep -qw "T48" <<< "$coords"; then
    b_ko "helper-lint: MERITO — T48 con maniglia NON è una violazione" "coordinate: '$coords'"
else
    b_ok "helper-lint: MERITO — T48 con maniglia non segnalata"
fi
