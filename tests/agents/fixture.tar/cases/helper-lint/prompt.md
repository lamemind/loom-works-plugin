attività: lint-niente-id

testo:
La catena bloccante resta T06 → T15 → T16 e nessuno la esplicita nel piano.
T48 (unificare docs-root) ha chiuso il canale doppio della configurazione.
Il fix è arrivato con la #4782, che nessuno ha più riletto.
