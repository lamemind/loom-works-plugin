# $1=envelope $2=fixture $3=transcript
env_f="$1"; fix="$2"
if jq -e 'has("ok") and (.aggiustamenti | type == "array")' "$env_f" >/dev/null 2>&1; then
    b_ok "validator: FORMA — envelope con ok e aggiustamenti"
else
    b_ko "validator: FORMA — envelope con ok e aggiustamenti" "$(cat "$env_f")"
fi
if jq -e '[.aggiustamenti[]] | all(.file != null and .violazione != null and .violazione != "" and .fix != null and .fix != "")' "$env_f" >/dev/null 2>&1; then
    b_ok "validator: FORMA — ogni aggiustamento con file, violazione e fix"
else
    b_ko "validator: FORMA — ogni aggiustamento con file, violazione e fix"
fi
# MERITO: le due violazioni piantate (data+task inline; T31 nudo) — almeno una
# trovata come aggiustamento, e nessun rollback chiesto (parola vietata)
found="$(jq -r '[.aggiustamenti[] | .violazione + " " + .fix + " " + (.punto // "")] | join(" | ")' "$env_f" 2>/dev/null)"
case "$found" in
    *[Tt]31*|*as-is*|*data*|*[Dd]ate*|*2026*|*task*|*cronaca*|*maniglia*|*coordinata*|*opac*)
        b_ok "validator: MERITO — violazioni piantate intercettate" ;;
    *)  b_ko "validator: MERITO — violazioni piantate intercettate" "aggiustamenti: $found" ;;
esac
if jq -e '.aggiustamenti | length >= 1' "$env_f" >/dev/null 2>&1; then
    b_ok "validator: MERITO — almeno un aggiustamento sulla patch sporca"
else
    b_ko "validator: MERITO — almeno un aggiustamento sulla patch sporca"
fi
# read-only: il working tree non deve essere cambiato dal validator — la patch
# piantata resta byte-identica a come l'ha lasciata pre.sh
if grep -q "documentato in T31" "$fix/docs/reference/cc/cc-transcript-store.md"; then
    b_ok "validator: FORMA — read-only, la patch non è stata toccata"
else
    b_ko "validator: FORMA — read-only, la patch non è stata toccata"
fi
