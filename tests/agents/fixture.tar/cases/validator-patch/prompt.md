perimetro: docs/reference/cc/cc-transcript-store.md
registro: docs/inbox/T109-cache-completo.md
guardiani: build-index: ok · check-doc-links: ok · doc-metrics: nessun flag nuovo
assumed_knowledge: docs/reference/assumed-knowledge.md
