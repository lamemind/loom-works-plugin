# applica al working tree la patch che il validator deve misurare: due
# violazioni piantate — una data+task inline, una coordinata opaca nuda
cat >> docs/reference/cc/cc-transcript-store.md <<'PATCH'

## Misurare la cache di un subagent

Aggiornato il 2026-08-26 per la task T109. Il consumo si legge dal primo record assistant del transcript: se il cache_read del secondo spawn copre il cache_creation del primo, il prefisso ha fatto match. Il caso limite è documentato in T31.
PATCH
