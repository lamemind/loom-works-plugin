# $1=envelope $2=fixture $3=transcript
env_f="$1"
n="$(jq -r '.verdetti | length' "$env_f" 2>/dev/null)"
if [[ "$n" == "5" ]]; then b_ok "router: FORMA — un verdetto per nozione (5)"; else b_ko "router: FORMA — un verdetto per nozione (5)" "trovati: $n"; fi
ids="$(jq -r '[.verdetti[].id] | sort | join(",")' "$env_f" 2>/dev/null)"
if [[ "$ids" == "n1,n2,n3,n4,n5" ]]; then b_ok "router: FORMA — id esatti n1..n5"; else b_ko "router: FORMA — id esatti n1..n5" "$ids"; fi
if jq -e '[.verdetti[].verdetto] | all(IN("rotta","noto","già scritto","drop"))' "$env_f" >/dev/null 2>&1; then
    b_ok "router: FORMA — verdetti nel vocabolario"
else
    b_ko "router: FORMA — verdetti nel vocabolario" "$(jq -c '[.verdetti[].verdetto]' "$env_f")"
fi
if jq -e '[.verdetti[] | select(.verdetto != "rotta")] | all(.motivo != null and .motivo != "")' "$env_f" >/dev/null 2>&1; then
    b_ok "router: FORMA — motivo su ogni non-azione"
else
    b_ko "router: FORMA — motivo su ogni non-azione"
fi
if jq -e '[.verdetti[]] | all(.evidenza != null and .evidenza != "")' "$env_f" >/dev/null 2>&1; then
    b_ok "router: FORMA — evidenza su ogni verdetto"
else
    b_ko "router: FORMA — evidenza su ogni verdetto"
fi
# MERITO (perimetro): n1..n3 parlano del meccanismo della cache — rotta verso reference/
# (file nuovo o esistente); n4 estende lo store dei transcript. Tollerante sul file
# esatto, intollerante sul layer: un target fuori da reference/ è fuori perimetro.
if jq -e '[.verdetti[] | select(.id | IN("n1","n2","n3","n4")) | select(.verdetto == "rotta")] | length >= 3' "$env_f" >/dev/null 2>&1; then
    b_ok "router: MERITO — almeno 3 delle 4 nozioni di meccanismo in rotta"
else
    b_ko "router: MERITO — almeno 3 delle 4 nozioni di meccanismo in rotta" "$(jq -c '[.verdetti[] | {id, verdetto}]' "$env_f")"
fi
if jq -e '[.verdetti[] | select(.verdetto == "rotta") | .target] | all(startswith("reference/"))' "$env_f" >/dev/null 2>&1; then
    b_ok "router: MERITO — ogni target sotto reference/"
else
    b_ko "router: MERITO — ogni target sotto reference/" "$(jq -c '[.verdetti[] | select(.verdetto == "rotta") | .target]' "$env_f")"
fi
if jq -e '[.verdetti[]] | all(.settore != null and .grado != null)' "$env_f" >/dev/null 2>&1; then
    b_ok "router: FORMA — settore e grado su ogni verdetto"
else
    b_ko "router: FORMA — settore e grado su ogni verdetto"
fi
