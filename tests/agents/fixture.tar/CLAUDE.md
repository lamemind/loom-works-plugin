# progetto-banco

Progetto congelato del banco agent di loom-works. Doc in `docs/`.
