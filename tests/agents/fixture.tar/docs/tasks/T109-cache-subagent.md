# Task: Ricerca sulla cache dei prompt per i subagent

- **ID**: T109
- **Size**: S
- **Progress**: ✔️ Done

## Description

Misurare il comportamento della cache prompt sui subagent e produrre le nozioni.
