# Assumed knowledge

> **TLDR**: competenza assunta del lettore della doc di questo progetto — set `settore: grado`, chiave `default`, catena settore → default → K2.

## Project assumed knowledge

- default: K2
- bash: K3
- git: K3
- claude code: K1
