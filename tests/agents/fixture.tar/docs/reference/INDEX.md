# Reference Index

Indice della documentazione offline.

## (root)

- `assumed-knowledge.md` — competenza assunta del lettore della doc di questo progetto — set `settore: grado`, chiave `default`, catena settore → default → K2.

## cc/

- `agent-sdk.md` — `@anthropic-ai/claude-agent-sdk` · client sottile che spawna la CLI installata · `query({prompt,options})` · fork di sessione via `forkSession`.
- `cc-transcript-store.md` — `~/.claude/projects/<hash>/*.jsonl` · hash del cwd coi non-alfanumerici resi `-`, lossy · leggere i transcript di una sessione · campi usage dei record assistant.
