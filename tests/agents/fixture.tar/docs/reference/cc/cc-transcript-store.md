# Transcript store di Claude Code

> **TLDR**: `~/.claude/projects/<hash>/*.jsonl` · hash del cwd coi non-alfanumerici resi `-`, lossy · leggere i transcript di una sessione · campi usage dei record assistant.

Ogni sessione Claude Code persiste il proprio transcript in `~/.claude/projects/<hash>/<session-id>.jsonl`, dove `<hash>` è il cwd con ogni carattere non alfanumerico reso `-`. La trasformazione è lossy: due cwd diversi possono collassare sulla stessa cartella.

I record `type: assistant` portano `message.usage` coi campi di consumo token. Il campo `message.content` può essere una stringa o un array di blocchi tipizzati: un lettore che assume la stringa si rompe sul primo transcript reale.
