# Agent SDK

> **TLDR**: `@anthropic-ai/claude-agent-sdk` · client sottile che spawna la CLI installata · `query({prompt,options})` · fork di sessione via `forkSession`.

L'SDK è un client sottile: spawna la CLI installata invece di vendorizzarne una, quindi SDK e CLI vanno in lockstep. Il fork di una sessione (`forkSession`) copia il transcript verbatim in una sessione nuova, senza riferimento all'origine.
