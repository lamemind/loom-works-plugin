# Tasks

## Tasks Overview

| ID  | Pri | Prog | Task (max 64) |
| --- | --- | ---- | ------------- |
| T109 | ⚡ | ✔️ | Ricerca sulla cache dei prompt per i subagent |

## Execution Plan

```
Legend: ✔️ Done  🟡 In Progress  🔒 Locked
```
